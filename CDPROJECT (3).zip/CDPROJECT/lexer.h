#ifndef LEXER_H
#define LEXER_H

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <cctype>
#include <fstream>

enum TokenType {
    // Keywords
    IF, ELIF, ELSE, END, PRINT, INPUT,
    
    // Operators
    PLUS, MINUS, MULT, DIV, POWER, ASSIGN, 
    
    // Relational operators
    EQ, NEQ, GT, LT, GTE, LTE,
    
    // Literals
    INT_LIT, FLOAT_LIT, STR_LIT, BOOL_LIT,
    
    // Other
    ID, LPAREN, RPAREN, LBRACKET, RBRACKET, COMMA, COLON, EOF_TOKEN,
    
    // Error token
    ERROR
};

struct Token {
    TokenType type;
    std::string lexeme;
    int line;
    
    Token(TokenType t, const std::string& l, int ln) : type(t), lexeme(l), line(ln) {}
    
    std::string toString() const {
        static const std::map<TokenType, std::string> typeNames = {
            {IF, "IF"}, {ELIF, "ELIF"}, {ELSE, "ELSE"}, {END, "END"},
            {PRINT, "PRINT"}, {INPUT, "INPUT"},
            {PLUS, "PLUS"}, {MINUS, "MINUS"}, {MULT, "MULT"}, {DIV, "DIV"},
            {POWER, "POWER"}, {ASSIGN, "ASSIGN"},
            {EQ, "EQ"}, {NEQ, "NEQ"}, {GT, "GT"}, {LT, "LT"}, {GTE, "GTE"}, {LTE, "LTE"},
            {INT_LIT, "INT_LIT"}, {FLOAT_LIT, "FLOAT_LIT"}, {STR_LIT, "STR_LIT"}, {BOOL_LIT, "BOOL_LIT"},
            {ID, "ID"}, {LPAREN, "LPAREN"}, {RPAREN, "RPAREN"},
            {LBRACKET, "LBRACKET"}, {RBRACKET, "RBRACKET"},
            {COMMA, "COMMA"}, {COLON, "COLON"}, {EOF_TOKEN, "EOF"},
            {ERROR, "ERROR"}
        };
        
        return "Token(" + typeNames.at(type) + ", \"" + lexeme + "\", line " + std::to_string(line) + ")";
    }
};

class Lexer {
private:
    std::string source;
    int position;
    int line;
    
    std::map<std::string, TokenType> keywords;
    
public:
    Lexer(const std::string& source);
    char peek();
    char advance();
    bool match(char expected);
    void skipWhitespace();
    Token scanToken();
    std::vector<Token> scanTokens();
};

#endif // LEXER_H