#ifndef PARSER_H
#define PARSER_H

#include "grammar.h"
#include "lexer.h"
#include "symbol_table.h"
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <string>

enum ActionType {
    ACTION_SHIFT,
    ACTION_REDUCE,
    ACTION_ACCEPT,
    ACTION_ERROR
};

struct Action {
    ActionType action;
    int state;      // For shift actions
    int ruleIndex;  // For reduce actions
    Action() : action(ACTION_ERROR), state(-1), ruleIndex(-1) {}
};

class Parser {
private:
    Grammar grammar;
    std::vector<Token> tokens;
    SymbolTable symbolTable;
    
    // LR(0) item representation
    struct LR0Item {
        int ruleIndex;
        int dotPosition;
        bool operator<(const LR0Item &other) const {
            return std::tie(ruleIndex, dotPosition) < std::tie(other.ruleIndex, other.dotPosition);
        }
        bool operator==(const LR0Item &other) const {
            return ruleIndex == other.ruleIndex && dotPosition == other.dotPosition;
        }
    };
    
    typedef std::set<LR0Item> ItemSet;
    std::vector<ItemSet> canonicalCollection;
    std::map<int, std::map<std::string, Action>> actionTable;
    std::map<int, std::map<std::string, int>> gotoTable;
    
    ItemSet closure(const ItemSet& items);
    ItemSet gotoFunction(const ItemSet& items, const std::string& symbol);
    void constructCanonicalCollection();
    void constructParsingTable();
    
    // Helper function to map a token to the corresponding grammar symbol
    std::string tokenToSymbol(const Token& token);
    
    // Structure for a parsing stack entry
    struct StackEntry {
        int state;
        std::string symbol;
        std::string lexeme;
        int line;
    };
    
public:
    Parser(const Grammar& grammar, const std::vector<Token>& tokens);
    bool parse();
    SymbolTable& getSymbolTable();
};

#endif // PARSER_H
