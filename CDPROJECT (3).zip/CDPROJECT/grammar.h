#ifndef GRAMMAR_H
#define GRAMMAR_H

#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>

// Structure to represent a production rule
struct Rule {
    std::string lhs;  // Left-hand side (non-terminal)
    std::vector<std::string> rhs;  // Right-hand side (sequence of symbols)
    
    Rule(const std::string& lhs, const std::vector<std::string>& rhs)
        : lhs(lhs), rhs(rhs) {}
    
    std::string toString() const;
};

// Class to represent the grammar
class Grammar {
private:
    std::vector<Rule> rules;
    std::set<std::string> terminals;
    std::set<std::string> nonTerminals;
    std::string startSymbol;
    
    // FIRST and FOLLOW sets
    std::map<std::string, std::set<std::string>> firstSets;
    std::map<std::string, std::set<std::string>> followSets;
    
public:
    Grammar();
    void addRule(const std::string& lhs, const std::vector<std::string>& rhs);
    const std::vector<Rule>& getRules() const;
    int getRuleIndex(const Rule& rule) const;
    bool isTerminal(const std::string& symbol) const;
    bool isNonTerminal(const std::string& symbol) const;
    const std::string& getStartSymbol() const;
    void computeFirstSets();
    void computeFollowSets();
    const std::set<std::string>& getFirstSet(const std::string& symbol) const;
    const std::set<std::string>& getFollowSet(const std::string& nonTerminal) const;
    std::set<std::string> getFirstOfSequence(const std::vector<std::string>& sequence) const;
    void printFirstSets() const;
    void printFollowSets() const;
};

#endif // GRAMMAR_H
