#include "lexer.h"

Lexer::Lexer(const std::string& source) : source(source), position(0), line(1) {
    // Initialize keywords map
    keywords["if"] = IF;
    keywords["elif"] = ELIF;
    keywords["else"] = ELSE;
    keywords["end"] = END;
    keywords["print"] = PRINT;
    keywords["input"] = INPUT;
    keywords["True"] = BOOL_LIT;
    keywords["False"] = BOOL_LIT;
}

char Lexer::peek() {
    if (position >= source.length()) {
        return '\0';
    }
    return source[position];
}

char Lexer::advance() {
    if (position >= source.length()) {
        return '\0';
    }
    if (source[position] == '\n') {
        line++;
    }
    return source[position++];
}

bool Lexer::match(char expected) {
    if (peek() != expected) {
        return false;
    }
    advance();
    return true;
}

void Lexer::skipWhitespace() {
    while (isspace(peek())) {
        advance();
    }
}

Token Lexer::scanToken() {
    skipWhitespace();
    
    if (position >= source.length()) {
        return Token(EOF_TOKEN, "", line);
    }
    
    char c = advance();
    
    // Handle identifiers and keywords
    if (isalpha(c) || c == '_') {
        int start = position - 1;
        while (isalnum(peek()) || peek() == '_') {
            advance();
        }
        
        std::string text = source.substr(start, position - start);
        
        // Check if it's a keyword
        if (keywords.find(text) != keywords.end()) {
            return Token(keywords[text], text, line);
        }
        
        // It's an identifier
        return Token(ID, text, line);
    }
    
    // Handle number literals (int and float)
    if (isdigit(c)) {
        int start = position - 1;
        bool isFloat = false;
        
        while (isdigit(peek()) || peek() == '.') {
            if (peek() == '.') {
                if (isFloat) {
                    // Error: More than one decimal point
                    return Token(ERROR, "Invalid number format: multiple decimal points", line);
                }
                isFloat = true;
            }
            advance();
        }
        
        std::string text = source.substr(start, position - start);
        return Token(isFloat ? FLOAT_LIT : INT_LIT, text, line);
    }
    
    // Handle string literals
    if (c == '"' || c == '\'') {
        char quote = c;
        int start = position;
        
        while (peek() != quote && peek() != '\0' && peek() != '\n') {
            advance();
        }
        
        if (peek() != quote) {
            return Token(ERROR, "Unterminated string", line);
        }
        
        std::string text = source.substr(start, position - start);
        advance(); // Consume the closing quote
        
        return Token(STR_LIT, text, line);
    }
    
    // Handle operators and other symbols
    switch (c) {
        case '+': return Token(PLUS, "+", line);
        case '-': return Token(MINUS, "-", line);
        case '*':
            if (match('*')) {
                return Token(POWER, "**", line);
            }
            return Token(MULT, "*", line);
        case '/': return Token(DIV, "/", line);
        case '=':
            if (match('=')) {
                return Token(EQ, "==", line);
            }
            return Token(ASSIGN, "=", line);
        case '!':
            if (match('=')) {
                return Token(NEQ, "!=", line);
            }
            return Token(ERROR, "Unexpected character '!'", line);
        case '>':
            if (match('=')) {
                return Token(GTE, ">=", line);
            }
            return Token(GT, ">", line);
        case '<':
            if (match('=')) {
                return Token(LTE, "<=", line);
            }
            return Token(LT, "<", line);
        case '(': return Token(LPAREN, "(", line);
        case ')': return Token(RPAREN, ")", line);
        case '[': return Token(LBRACKET, "[", line);
        case ']': return Token(RBRACKET, "]", line);
        case ',': return Token(COMMA, ",", line);
        case ':': return Token(COLON, ":", line);
        case '#': // Handle comments
            while (peek() != '\n' && peek() != '\0') {
                advance();
            }
            return scanToken();
        default:
            return Token(ERROR, "Unexpected character '" + std::string(1, c) + "'", line);
    }
}

std::vector<Token> Lexer::scanTokens() {
    std::vector<Token> tokens;
    
    while (position < source.length()) {
        Token token = scanToken();
        tokens.push_back(token);
        
        if (token.type == EOF_TOKEN) {
            break;
        }
    }
    
    return tokens;
}