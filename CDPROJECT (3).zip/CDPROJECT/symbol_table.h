#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include <iostream>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

// Define the possible data types
enum class DataType {
    INT,
    FLOAT,
    STRING,
    BOOLEAN,
    LIST,
    UNKNOWN
};

// Value class to hold different types of values
using ValueType = std::variant<int, double, std::string, bool, std::vector<std::variant<int, double, std::string, bool>>>;

class SymbolEntry {
private:
    std::string name;
    DataType type;
    ValueType value;
    bool initialized;
    int scope;
    int line;

public:
    SymbolEntry(const std::string& name, int scope, int line);
    void setType(DataType type);
    void setValue(const ValueType& value);
    DataType getType() const;
    ValueType getValue() const;
    std::string getName() const;
    bool isInitialized() const;
    int getScope() const;
    int getLine() const;
    std::string toString() const;
};

class SymbolTable {
private:
    // Using a vector of maps to handle nested scopes
    std::vector<std::unordered_map<std::string, SymbolEntry>> scopes;
    int currentScope;

public:
    SymbolTable();
    void enterScope();
    void exitScope();
    SymbolEntry* define(const std::string& name, int line);
    SymbolEntry* lookup(const std::string& name);
    void printCurrentScope() const;
    void printAllScopes() const;
};

#endif // SYMBOL_TABLE_H