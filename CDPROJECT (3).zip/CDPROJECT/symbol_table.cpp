#include "symbol_table.h"

SymbolEntry::SymbolEntry(const std::string& name, int scope, int line)
    : name(name), type(DataType::UNKNOWN), initialized(false), scope(scope), line(line) {}

void SymbolEntry::setType(DataType type) {
    this->type = type;
}

void SymbolEntry::setValue(const ValueType& value) {
    this->value = value;
    initialized = true;
    
    // Determine type based on value
    if (std::holds_alternative<int>(value)) {
        type = DataType::INT;
    } else if (std::holds_alternative<double>(value)) {
        type = DataType::FLOAT;
    } else if (std::holds_alternative<std::string>(value)) {
        type = DataType::STRING;
    } else if (std::holds_alternative<bool>(value)) {
        type = DataType::BOOLEAN;
    } else {
        type = DataType::LIST;
    }
}

DataType SymbolEntry::getType() const {
    return type;
}

ValueType SymbolEntry::getValue() const {
    return value;
}

std::string SymbolEntry::getName() const {
    return name;
}

bool SymbolEntry::isInitialized() const {
    return initialized;
}

int SymbolEntry::getScope() const {
    return scope;
}

int SymbolEntry::getLine() const {
    return line;
}

std::string SymbolEntry::toString() const {
    std::string result = "Symbol(name=" + name + ", type=";
    
    switch (type) {
        case DataType::INT:
            result += "INT";
            break;
        case DataType::FLOAT:
            result += "FLOAT";
            break;
        case DataType::STRING:
            result += "STRING";
            break;
        case DataType::BOOLEAN:
            result += "BOOLEAN";
            break;
        case DataType::LIST:
            result += "LIST";
            break;
        default:
            result += "UNKNOWN";
    }
    
    result += ", initialized=" + std::string(initialized ? "true" : "false");
    result += ", scope=" + std::to_string(scope);
    result += ", line=" + std::to_string(line);
    result += ")";
    
    return result;
}

SymbolTable::SymbolTable() : currentScope(0) {
    // Create global scope
    scopes.push_back({});
}

void SymbolTable::enterScope() {
    currentScope++;
    if (currentScope >= scopes.size()) {
        scopes.push_back({});
    }
}

void SymbolTable::exitScope() {
    if (currentScope > 0) {
        currentScope--;
    }
}

SymbolEntry* SymbolTable::define(const std::string& name, int line) {
    // Check if symbol already exists in current scope
    auto& currentScopeTable = scopes[currentScope];
    if (currentScopeTable.find(name) != currentScopeTable.end()) {
        return &currentScopeTable[name];
    }

    // Add new symbol
    SymbolEntry entry(name, currentScope, line);
    currentScopeTable[name] = entry;
    return &currentScopeTable[name];
}

SymbolEntry* SymbolTable::lookup(const std::string& name) {
    // Search from current scope outward
    for (int scope = currentScope; scope >= 0; scope--) {
        auto& scopeTable = scopes[scope];
        if (scopeTable.find(name) != scopeTable.end()) {
            return &scopeTable[name];
        }
    }
    return nullptr;
}

void SymbolTable::printCurrentScope() const {
    std::cout << "Current Scope: " << currentScope << std::endl;
    const auto& scopeTable = scopes[currentScope];
    
    for (const auto& [name, entry] : scopeTable) {
        std::cout << entry.toString() << std::endl;
    }
}

void SymbolTable::printAllScopes() const {
    for (size_t i = 0; i < scopes.size(); i++) {
        std::cout << "Scope " << i << ":" << std::endl;
        const auto& scopeTable = scopes[i];
        
        if (scopeTable.empty()) {
            std::cout << "  <empty>" << std::endl;
            continue;
        }
        
        for (const auto& [name, entry] : scopeTable) {
            std::cout << "  " << entry.toString() << std::endl;
        }
    }
}