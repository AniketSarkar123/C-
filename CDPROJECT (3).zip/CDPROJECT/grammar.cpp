#include "grammar.h"

std::string Rule::toString() const {
    std::string result = lhs + " -> ";
    for (const auto& symbol : rhs) {
        result += symbol + " ";
    }
    if (rhs.empty()) {
         result += "ε ";
    }
    return result;
}

Grammar::Grammar() {
    // Add augmented start rule
    addRule("S'", {"program"});
    startSymbol = "S'";
}

void Grammar::addRule(const std::string& lhs, const std::vector<std::string>& rhs) {
    rules.emplace_back(lhs, rhs);
    nonTerminals.insert(lhs);
    
    for (const auto& symbol : rhs) {
        // If symbol starts with uppercase, it's a non-terminal
        if (!symbol.empty() && isupper(symbol[0])) {
            nonTerminals.insert(symbol);
        } else if (!symbol.empty() && symbol != "ε") {
            terminals.insert(symbol);
        }
    }
}

const std::vector<Rule>& Grammar::getRules() const {
    return rules;
}

int Grammar::getRuleIndex(const Rule& rule) const {
    for (size_t i = 0; i < rules.size(); i++) {
        if (rules[i].lhs == rule.lhs && rules[i].rhs == rule.rhs) {
            return i;
        }
    }
    return -1;
}

bool Grammar::isTerminal(const std::string& symbol) const {
    return terminals.find(symbol) != terminals.end();
}

bool Grammar::isNonTerminal(const std::string& symbol) const {
    return nonTerminals.find(symbol) != nonTerminals.end();
}

const std::string& Grammar::getStartSymbol() const {
    return startSymbol;
}

void Grammar::computeFirstSets() {
    // Initialize FIRST sets for terminals
    for (const auto& terminal : terminals) {
        firstSets[terminal].insert(terminal);
    }
    // Initialize FIRST sets for nonterminals as empty
    for (const auto& nonTerminal : nonTerminals) {
        firstSets[nonTerminal] = {};
    }
    
    bool changed = true;
    while (changed) {
        changed = false;
        for (const auto& rule : rules) {
            const std::string& lhs = rule.lhs;
            const std::vector<std::string>& rhs = rule.rhs;
            
            if (rhs.empty() || (rhs.size() == 1 && rhs[0] == "ε")) {
                if (firstSets[lhs].insert("ε").second) {
                    changed = true;
                }
                continue;
            }
            
            bool allCanDeriveEmpty = true;
            for (const auto& symbol : rhs) {
                const auto& firstSet = firstSets[symbol];
                bool hasEpsilon = (firstSet.find("ε") != firstSet.end());
                for (const auto& s : firstSet) {
                    if (s != "ε") {
                        if (firstSets[lhs].insert(s).second) {
                            changed = true;
                        }
                    }
                }
                if (!hasEpsilon) {
                    allCanDeriveEmpty = false;
                    break;
                }
            }
            if (allCanDeriveEmpty) {
                if (firstSets[lhs].insert("ε").second) {
                    changed = true;
                }
            }
        }
    }
}

void Grammar::computeFollowSets() {
    // Initialize FOLLOW sets for nonterminals
    for (const auto& nonTerminal : nonTerminals) {
        followSets[nonTerminal] = {};
    }
    // Add end marker to start symbol
    followSets[startSymbol].insert("$");
    
    bool changed = true;
    while (changed) {
        changed = false;
        for (const auto& rule : rules) {
            const std::string& lhs = rule.lhs;
            const std::vector<std::string>& rhs = rule.rhs;
            
            for (size_t i = 0; i < rhs.size(); i++) {
                if (isNonTerminal(rhs[i])) {
                    bool allCanDeriveEmpty = true;
                    for (size_t j = i + 1; j < rhs.size(); j++) {
                        const auto& firstSet = firstSets[rhs[j]];
                        for (const auto& symbol : firstSet) {
                            if (symbol != "ε") {
                                if (followSets[rhs[i]].insert(symbol).second)
                                    changed = true;
                            }
                        }
                        if (firstSet.find("ε") == firstSet.end()) {
                            allCanDeriveEmpty = false;
                            break;
                        }
                    }
                    if (allCanDeriveEmpty) {
                        for (const auto& symbol : followSets[lhs]) {
                            if (followSets[rhs[i]].insert(symbol).second)
                                changed = true;
                        }
                    }
                }
            }
        }
    }
}

const std::set<std::string>& Grammar::getFirstSet(const std::string& symbol) const {
    static std::set<std::string> emptySet;
    auto it = firstSets.find(symbol);
    if (it != firstSets.end()) {
        return it->second;
    }
    return emptySet;
}

const std::set<std::string>& Grammar::getFollowSet(const std::string& nonTerminal) const {
    static std::set<std::string> emptySet;
    auto it = followSets.find(nonTerminal);
    if (it != followSets.end()) {
        return it->second;
    }
    return emptySet;
}

std::set<std::string> Grammar::getFirstOfSequence(const std::vector<std::string>& sequence) const {
    std::set<std::string> result;
    if (sequence.empty()) {
        result.insert("ε");
        return result;
    }
    bool allCanDeriveEmpty = true;
    for (const auto& symbol : sequence) {
        const auto& firstSet = getFirstSet(symbol);
        bool containsEpsilon = (firstSet.find("ε") != firstSet.end());
        for (const auto& s : firstSet) {
            if (s != "ε") {
                result.insert(s);
            }
        }
        if (!containsEpsilon) {
            allCanDeriveEmpty = false;
            break;
        }
    }
    if (allCanDeriveEmpty) {
        result.insert("ε");
    }
    return result;
}

void Grammar::printFirstSets() const {
    std::cout << "FIRST sets:" << std::endl;
    for (const auto& entry : firstSets) {
        std::cout << "FIRST(" << entry.first << ") = { ";
        for (const auto& s : entry.second) {
            std::cout << s << " ";
        }
        std::cout << "}" << std::endl;
    }
}

void Grammar::printFollowSets() const {
    std::cout << "FOLLOW sets:" << std::endl;
    for (const auto& entry : followSets) {
        std::cout << "FOLLOW(" << entry.first << ") = { ";
        for (const auto& s : entry.second) {
            std::cout << s << " ";
        }
        std::cout << "}" << std::endl;
    }
}
