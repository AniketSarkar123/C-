#include "parser.h"
#include <iostream>
#include <sstream>
#include <tuple>
#include <algorithm>

Parser::Parser(const Grammar& grammar, const std::vector<Token>& tokens)
    : grammar(grammar), tokens(tokens) {
    constructCanonicalCollection();
    constructParsingTable();
}

std::string Parser::tokenToSymbol(const Token& token) {
    switch(token.type) {
        case IF: return "IF";
        case ELIF: return "ELIF";
        case ELSE: return "ELSE";
        case END: return "END";
        case PRINT: return "PRINT";
        case INPUT: return "INPUT";
        case ID: return "ID";
        case INT_LIT: return "INT_LIT";
        case FLOAT_LIT: return "FLOAT_LIT";
        case STR_LIT: return "STR_LIT";
        case BOOL_LIT: return "BOOL_LIT";
        case PLUS: return "+";
        case MINUS: return "-";
        case MULT: return "*";
        case DIV: return "/";
        case POWER: return "**";
        case ASSIGN: return "=";
        case EQ: return "==";
        case NEQ: return "!=";
        case GT: return ">";
        case LT: return "<";
        case GTE: return ">=";
        case LTE: return "<=";
        case LPAREN: return "(";
        case RPAREN: return ")";
        case LBRACKET: return "[";
        case RBRACKET: return "]";
        case COMMA: return ",";
        case COLON: return ":";
        case EOF_TOKEN: return "$";
        default: return "ERROR";
    }
}

Parser::ItemSet Parser::closure(const ItemSet& items) {
    ItemSet closureSet = items;
    bool changed = true;
    while(changed) {
        changed = false;
        ItemSet temp = closureSet;
        for (const auto& item : temp) {
            const Rule& rule = grammar.getRules()[item.ruleIndex];
            if (item.dotPosition < rule.rhs.size()) {
                std::string symbol = rule.rhs[item.dotPosition];
                if (grammar.isNonTerminal(symbol)) {
                    for (int i = 0; i < grammar.getRules().size(); i++) {
                        const Rule& r = grammar.getRules()[i];
                        if (r.lhs == symbol) {
                            LR0Item newItem {i, 0};
                            if (closureSet.find(newItem) == closureSet.end()) {
                                closureSet.insert(newItem);
                                changed = true;
                            }
                        }
                    }
                }
            }
        }
    }
    return closureSet;
}

Parser::ItemSet Parser::gotoFunction(const ItemSet& items, const std::string& symbol) {
    ItemSet gotoSet;
    for (const auto& item : items) {
        const Rule& rule = grammar.getRules()[item.ruleIndex];
        if (item.dotPosition < rule.rhs.size() && rule.rhs[item.dotPosition] == symbol) {
            LR0Item newItem { item.ruleIndex, item.dotPosition + 1 };
            gotoSet.insert(newItem);
        }
    }
    return closure(gotoSet);
}

void Parser::constructCanonicalCollection() {
    canonicalCollection.clear();
    // Start with the augmented start rule
    ItemSet startItems;
    for (int i = 0; i < grammar.getRules().size(); i++) {
        const Rule& rule = grammar.getRules()[i];
        if (rule.lhs == grammar.getStartSymbol()) {
            startItems.insert({i, 0});
        }
    }
    ItemSet I0 = closure(startItems);
    canonicalCollection.push_back(I0);
    
    // Gather all symbols from the grammar (ignoring epsilon)
    std::set<std::string> symbols;
    for (const auto& rule : grammar.getRules()) {
        for (const auto& sym : rule.rhs) {
            if (sym != "ε") {
                symbols.insert(sym);
            }
        }
    }
    
    bool added = true;
    while(added) {
        added = false;
        int collectionSize = canonicalCollection.size();
        for (int i = 0; i < collectionSize; i++) {
            for (const auto& symbol : symbols) {
                ItemSet gotoSet = gotoFunction(canonicalCollection[i], symbol);
                if (!gotoSet.empty()) {
                    bool exists = false;
                    for (const auto& itemSet : canonicalCollection) {
                        if (itemSet == gotoSet) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        canonicalCollection.push_back(gotoSet);
                        added = true;
                    }
                }
            }
        }
    }
}

void Parser::constructParsingTable() {
    // Construct ACTION and GOTO tables for each state
    for (int i = 0; i < canonicalCollection.size(); i++) {
        for (const auto& item : canonicalCollection[i]) {
            const Rule& rule = grammar.getRules()[item.ruleIndex];
            if (item.dotPosition < rule.rhs.size()) {
                std::string symbol = rule.rhs[item.dotPosition];
                ItemSet gotoSet = gotoFunction(canonicalCollection[i], symbol);
                int targetState = -1;
                for (int j = 0; j < canonicalCollection.size(); j++) {
                    if (canonicalCollection[j] == gotoSet) {
                        targetState = j;
                        break;
                    }
                }
                if (targetState != -1) {
                    if (grammar.isTerminal(symbol)) {
                        actionTable[i][symbol] = Action { ACTION_SHIFT, targetState, -1 };
                    } else {
                        gotoTable[i][symbol] = targetState;
                    }
                }
            } else {
                // Completed production item
                if (rule.lhs == grammar.getStartSymbol()) {
                    actionTable[i]["$"] = Action { ACTION_ACCEPT, -1, -1 };
                } else {
                    const auto& follow = grammar.getFollowSet(rule.lhs);
                    for (const auto& terminal : follow) {
                        actionTable[i][terminal] = Action { ACTION_REDUCE, -1, item.ruleIndex };
                    }
                }
            }
        }
    }
}

bool Parser::parse() {
    // Parsing stack: each entry holds state, symbol, lexeme, and token line number.
    std::vector<StackEntry> stack;
    stack.push_back({0, "", "", 0});
    
    int tokenIndex = 0;
    Token currentToken = tokens[tokenIndex];
    std::string lookahead = tokenToSymbol(currentToken);
    
    while (true) {
        int currentState = stack.back().state;
        Action action;
        if (actionTable[currentState].find(lookahead) != actionTable[currentState].end()) {
            action = actionTable[currentState][lookahead];
        } else {
            action.action = ACTION_ERROR;
        }
        
        if (action.action == ACTION_SHIFT) {
            int nextState = action.state;
            stack.push_back({nextState, lookahead, currentToken.lexeme, currentToken.line});
            tokenIndex++;
            if (tokenIndex < tokens.size()) {
                currentToken = tokens[tokenIndex];
                lookahead = tokenToSymbol(currentToken);
            } else {
                lookahead = "$";
            }
        } else if (action.action == ACTION_REDUCE) {
            const Rule& rule = grammar.getRules()[action.ruleIndex];
            int prodSize = rule.rhs.size();
            std::vector<StackEntry> popped;
            for (int i = 0; i < prodSize; i++) {
                if (!stack.empty()) {
                    popped.push_back(stack.back());
                    stack.pop_back();
                }
            }
            std::reverse(popped.begin(), popped.end());
            int stateAfterReduction = stack.back().state;
            int gotoState = -1;
            if (gotoTable[stateAfterReduction].find(rule.lhs) != gotoTable[stateAfterReduction].end()) {
                gotoState = gotoTable[stateAfterReduction][rule.lhs];
            } else {
                std::cerr << "Error: GOTO table missing entry for state " << stateAfterReduction 
                          << " and symbol " << rule.lhs << std::endl;
                return false;
            }
            // Minimal semantic action: for assignment_stmt, add the identifier to the symbol table.
            if (rule.lhs == "assignment_stmt" && !popped.empty()) {
                // Assuming production: assignment_stmt -> ID = expr
                if (popped[0].symbol == "ID") {
                    symbolTable.define(popped[0].lexeme, popped[0].line);
                }
            }
            stack.push_back({gotoState, rule.lhs, "", popped.empty() ? 0 : popped.front().line});
        } else if (action.action == ACTION_ACCEPT) {
            std::cout << "Parsing successful!" << std::endl;
            return true;
        } else {
            std::cerr << "Parsing error at token: " << currentToken.toString() << std::endl;
            return false;
        }
    }
    
    return false;
}

SymbolTable& Parser::getSymbolTable() {
    return symbolTable;
}
