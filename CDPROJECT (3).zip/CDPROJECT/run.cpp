#include <iostream>
#include <fstream>
#include <string>
#include "lexer.h"
#include "symbol_table.h"
#include "parser.h"

void readFileContents(const std::string& filename, std::string& content) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        exit(1);
    }
    
    content = std::string(
        (std::istreambuf_iterator<char>(file)),
        std::istreambuf_iterator<char>()
    );
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "Usage: " << argv[0] << " <source_file>" << std::endl;
        return 1;
    }
    
    std::string sourceCode;
    readFileContents(argv[1], sourceCode);
    
    // Initialize the lexer
    Lexer lexer(sourceCode);
    std::vector<Token> tokens = lexer.scanTokens();
    
    std::cout << "=== Lexical Analysis Results ===" << std::endl;
    for (const Token& token : tokens) {
        std::cout << token.toString() << std::endl;
    }
    
    // Initialize the grammar
    Grammar grammar;
    
    // Add grammar rules
    // Program and statements
    grammar.addRule("program", {"statement_list"});
    grammar.addRule("statement_list", {"statement", "statement_list"});
    grammar.addRule("statement_list", {}); // Empty production
    
    // Statements
    grammar.addRule("statement", {"assignment_stmt"});
    grammar.addRule("statement", {"if_stmt"});
    grammar.addRule("statement", {"print_stmt"});
    grammar.addRule("statement", {"input_stmt"});
    
    // Assignment statement
    grammar.addRule("assignment_stmt", {"ID", "=", "expr"});
    
    // If statement
    grammar.addRule("if_stmt", {"IF", "condition", ":", "statement_list", "END"});
    grammar.addRule("if_stmt", {"IF", "condition", ":", "statement_list", "ELSE", ":", "statement_list", "END"});
    grammar.addRule("if_stmt", {"IF", "condition", ":", "statement_list", "elif_list", "END"});
    grammar.addRule("if_stmt", {"IF", "condition", ":", "statement_list", "elif_list", "ELSE", ":", "statement_list", "END"});
    
    // Elif list
    grammar.addRule("elif_list", {"ELIF", "condition", ":", "statement_list"});
    grammar.addRule("elif_list", {"ELIF", "condition", ":", "statement_list", "elif_list"});
    
    // Print statement
    grammar.addRule("print_stmt", {"PRINT", "(", "expr", ")"});
    
    // Input statement
    grammar.addRule("input_stmt", {"ID", "=", "INPUT", "(", ")"});
    
    // Expressions
    grammar.addRule("expr", {"term"});
    grammar.addRule("expr", {"expr", "+", "term"});
    grammar.addRule("expr", {"expr", "-", "term"});
    
    // Terms
    grammar.addRule("term", {"factor"});
    grammar.addRule("term", {"term", "*", "factor"});
    grammar.addRule("term", {"term", "/", "factor"});
    
    // Factors
    grammar.addRule("factor", {"primary"});
    grammar.addRule("factor", {"factor", "**", "primary"});
    
    // Primary expressions
    grammar.addRule("primary", {"ID"});
    grammar.addRule("primary", {"INT_LIT"});
    grammar.addRule("primary", {"FLOAT_LIT"});
    grammar.addRule("primary", {"STR_LIT"});
    grammar.addRule("primary", {"BOOL_LIT"});
    grammar.addRule("primary", {"(", "expr", ")"});
    grammar.addRule("primary", {"list_expr"});
    
    // List expressions
    grammar.addRule("list_expr", {"[", "expr_list", "]"});
    
    // Expression list
    grammar.addRule("expr_list", {"expr", ",", "expr_list"});
    grammar.addRule("expr_list", {"expr"});
    grammar.addRule("expr_list", {}); // Empty list
    
    // Conditions
    grammar.addRule("condition", {"expr", "relop", "expr"});
    grammar.addRule("condition", {"expr"});
    
    // Relational operators
    grammar.addRule("relop", {"=="});
    grammar.addRule("relop", {"!="});
    grammar.addRule("relop", {">"});
    grammar.addRule("relop", {"<"});
    grammar.addRule("relop", {">="});
    grammar.addRule("relop", {"<="});
    
    // Compute FIRST and FOLLOW sets
    std::cout << "\n=== Computing FIRST and FOLLOW sets ===" << std::endl;
    grammar.computeFirstSets();
    grammar.computeFollowSets();
    
    grammar.printFirstSets();
    grammar.printFollowSets();
    
    // Initialize the parser
    Parser parser(grammar, tokens);
    bool success = parser.parse();
    
    std::cout << "\n=== Parsing Result ===" << std::endl;
    if (success) {
        std::cout << "Parsing successful!" << std::endl;
    } else {
        std::cout << "Parsing failed!" << std::endl;
    }
    
    // Print symbol table
    SymbolTable& symbolTable = parser.getSymbolTable();
    std::cout << "\n=== Symbol Table ===" << std::endl;
    symbolTable.printAllScopes();
    
    return 0;
}