import socket
import struct
from packetmanager import PacketManager
import time

SERVER_IP = '127.0.0.1'
SERVER_PORT = 65432

# Example ARP table
ARP_TABLE = {
    '192.168.1.1': '00:0A:95:9D:68:16',
    '192.168.1.2': '00:0A:95:9D:68:17',
    '192.168.1.3': '00:0A:95:9D:68:18',
    '192.168.1.4': '00:0A:95:9D:68:19',
}

print("ARP server is running...")

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
    server_socket.bind((SERVER_IP, SERVER_PORT))
    server_socket.listen()

    while True:
        conn, addr = server_socket.accept()
        with conn:
            print(f"Connected to {addr}")
            while True:
                # Receive packet from the client
                packet_data = conn.recv(1024)
                if not packet_data:
                    break
                
                # Unpack the received data
                data = PacketManager.unpack_packet(packet_data)

                # Get the destination IP from the packet
                dest_ip = data['dest_ip']
                # Look up the MAC address for the destination IP in the ARP table
                dest_mac = ARP_TABLE.get(dest_ip, 'Not Found')

                # Log the response being sent
                print(f"Sending ARP response for IP: {dest_ip} -> MAC: {dest_mac}")

                # Create a response packet
                response_data = {
                    'src_ip': data['dest_ip'],   # Source IP is the destination IP of the request
                    'src_mac': dest_mac,         # Source MAC is the MAC address from the ARP table
                    'dest_ip': data['src_ip'],   # Destination IP is the source IP of the request
                    'dest_mac': data['src_mac'], # Destination MAC is the MAC address of the client
                    'timestamp': time.time()
                }
                response_packet = PacketManager.create_packet(response_data)
                conn.sendall(response_packet)
