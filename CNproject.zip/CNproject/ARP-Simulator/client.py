import socket
import time
from packetmanager import PacketManager

SERVER_IP = '127.0.0.1'
SERVER_PORT = 65432

ARP_TABLE = {}

# Function to validate the IP format
def validate_ip(ip):
    parts = ip.split('.')
    if len(parts) != 4:
        return False
    for part in parts:
        if not part.isdigit() or not 0 <= int(part) <= 255:
            return False
    return True

print("Client is running...")

while True:
    ip = input("Enter IP to ARP for: ")

    # Validate the IP format before sending the request
    if not validate_ip(ip):
        print("Invalid IP format. Please enter a valid IP address.")
        continue

    # Create a request packet
    timestamp = time.time()
    data = {
        'src_ip': '192.168.1.100',  # Example client IP
        'src_mac': '00:0A:95:9D:68:10',  # Example client MAC
        'dest_ip': ip,
        'dest_mac': '',
        'timestamp': timestamp
    }
    
    request_packet = PacketManager.create_packet(data)
    
    # Print the packet data being sent
    print(f"Sending ARP request for IP: {ip} with packet: {data}")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((SERVER_IP, SERVER_PORT))
        s.sendall(request_packet)
        response_data = s.recv(1024)
    
    # Unpack the response packet and update the ARP table
    response = PacketManager.unpack_packet(response_data)
    
    # Update ARP table with the received MAC address
    if response['dest_mac'] != 'Not Found':
        ARP_TABLE[response['dest_ip']] = response['dest_mac']
        print(f"Received ARP reply: {response['dest_ip']} is at {response['dest_mac']}")
    else:
        print(f"No ARP reply for {response['dest_ip']}")

    print("Current ARP Table:", ARP_TABLE)
