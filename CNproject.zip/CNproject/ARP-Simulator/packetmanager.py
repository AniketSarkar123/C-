import struct
import time

class PacketManager:
    @staticmethod
    def create_packet(data):
        # Extract data from dictionary
        src_ip = data['src_ip']
        src_mac = data['src_mac']
        dest_ip = data['dest_ip']
        dest_mac = data['dest_mac']
        timestamp = data['timestamp']

        # Log the data being packed
        print(f"Creating packet with data: {data}")
        
        packet_format = '!16s 16s 16s 16s d'  # Format for packing the data (for IPs, MACs, and timestamp)
        packed_data = struct.pack(packet_format, 
                                  src_ip.encode('utf-8'), 
                                  src_mac.encode('utf-8'), 
                                  dest_ip.encode('utf-8'), 
                                  dest_mac.encode('utf-8'), 
                                  timestamp)
        return packed_data

    @staticmethod
    def unpack_packet(packet_data):
        # Define the unpacking format for the packet
        packet_format = '!16s 16s 16s 16s d'
        unpacked_data = struct.unpack(packet_format, packet_data)
        
        # Decode the unpacked data into strings and float
        data = {
            'src_ip': unpacked_data[0].decode('utf-8').strip('\x00'),
            'src_mac': unpacked_data[1].decode('utf-8').strip('\x00'),
            'dest_ip': unpacked_data[2].decode('utf-8').strip('\x00'),
            'dest_mac': unpacked_data[3].decode('utf-8').strip('\x00'),
            'timestamp': unpacked_data[4]
        }

        # Log the unpacked data
        print(f"Unpacked data: {data}")
        return data
